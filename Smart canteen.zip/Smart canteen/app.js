const products = [
  {id:1,name:"Veg Burger",category:"Snacks",price:60,emoji:"🍔",desc:"Fresh vegetable patty with creamy sauce."},
  {id:2,name:"Cheese Pizza",category:"Snacks",price:120,emoji:"🍕",desc:"Cheesy pizza with fresh vegetables."},
  {id:3,name:"Masala Dosa",category:"Meals",price:80,emoji:"🥞",desc:"Crispy dosa served with chutney."},
  {id:4,name:"Veg Sandwich",category:"Snacks",price:50,emoji:"🥪",desc:"Grilled sandwich with fresh vegetables."},
  {id:5,name:"Cold Coffee",category:"Drinks",price:55,emoji:"🥤",desc:"Chilled creamy coffee."},
  {id:6,name:"Fresh Juice",category:"Drinks",price:40,emoji:"🧃",desc:"Refreshing seasonal fruit juice."},
  {id:7,name:"French Fries",category:"Snacks",price:70,emoji:"🍟",desc:"Golden crispy salted fries."},
  {id:8,name:"Veg Thali",category:"Meals",price:110,emoji:"🍛",desc:"Complete meal with roti, rice and curry."},
  {id:9,name:"Chole Bhature",category:"Meals",price:90,emoji:"🍲",desc:"Delicious chole with soft bhature."}
];

let cart = JSON.parse(localStorage.getItem("cart")) || [];
let orders = JSON.parse(localStorage.getItem("orders")) || [];
let activeCategory = "All";

const $ = id => document.getElementById(id);

function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

function saveOrders() {
  localStorage.setItem("orders", JSON.stringify(orders));
}

function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  setTimeout(() => $("toast").classList.remove("show"), 2200);
}

// CATEGORIES

function renderCategories() {
  const categories = ["All","Snacks","Meals","Drinks"];

  $("categories").innerHTML = categories.map(c => `
    <button class="category-btn ${activeCategory === c ? "active" : ""}"
    data-category="${c}">${c}</button>
  `).join("");
}

$("categories").addEventListener("click", e => {
  const button = e.target.closest("[data-category]");
  if (!button) return;
  activeCategory = button.dataset.category;
  renderCategories();
  renderProducts();
});

// MENU

function renderProducts() {
  const search = $("searchInput").value.toLowerCase();

  const filtered = products.filter(p =>
    (activeCategory === "All" || p.category === activeCategory) &&
    p.name.toLowerCase().includes(search)
  );

  $("menuGrid").innerHTML = filtered.length ? filtered.map(p => `
    <article class="food-card">
      <div class="food-visual">${p.emoji}</div>
      <div class="food-info">
        <h3>${p.name}</h3>
        <p>${p.desc}</p>
        <div class="food-bottom">
          <span class="food-price">₹${p.price}</span>
          <button class="add-btn" data-add="${p.id}">+ Add</button>
        </div>
      </div>
    </article>
  `).join("") : "<p>No dishes found.</p>";
}

$("searchInput").addEventListener("input", renderProducts);

// CART

function total() {
  return cart.reduce((sum,item) => {
    const p = products.find(p => p.id === item.id);
    return sum + p.price * item.quantity;
  },0);
}

function updateCart() {
  $("cartCount").textContent = cart.reduce((s,i) => s+i.quantity,0);
  $("cartTotal").textContent = "₹" + total();
  $("checkoutTotal").textContent = "₹" + total();

  if (!cart.length) {
    $("cartItems").innerHTML = `
      <div class="empty-cart">
        <div style="font-size:45px">🛒</div>
        <h3>Your cart is empty</h3>
        <p>Add something delicious!</p>
      </div>`;
    return;
  }

  $("cartItems").innerHTML = cart.map(item => {
    const p = products.find(p => p.id === item.id);
    return `
      <div class="cart-item">
        <div class="cart-emoji">${p.emoji}</div>
        <div class="cart-item-info">
          <h4>${p.name}</h4>
          <p>₹${p.price * item.quantity}</p>
        </div>
        <div class="quantity-controls">
          <button data-minus="${p.id}">−</button>
          <span>${item.quantity}</span>
          <button data-plus="${p.id}">+</button>
        </div>
      </div>`;
  }).join("");
}

$("menuGrid").addEventListener("click", e => {
  const button = e.target.closest("[data-add]");
  if (!button) return;

  const id = Number(button.dataset.add);
  const item = cart.find(i => i.id === id);

  if (item) item.quantity++;
  else cart.push({id,quantity:1});

  saveCart();
  updateCart();
  toast("Item added to cart!");
});

$("cartItems").addEventListener("click", e => {
  const plus = e.target.closest("[data-plus]");
  const minus = e.target.closest("[data-minus]");

  if (plus) {
    cart.find(i => i.id === Number(plus.dataset.plus)).quantity++;
  }

  if (minus) {
    const id = Number(minus.dataset.minus);
    const item = cart.find(i => i.id === id);
    item.quantity--;
    if (item.quantity <= 0) cart = cart.filter(i => i.id !== id);
  }

  saveCart();
  updateCart();
});

// OVERLAYS

function open(id) { $(id).classList.add("show"); }
function close(id) { $(id).classList.remove("show"); }

$("cartOpen").addEventListener("click", () => open("cartOverlay"));
$("adminOpen").addEventListener("click", () => open("adminOverlay"));

document.querySelectorAll("[data-close]").forEach(btn => {
  btn.addEventListener("click", () => close(btn.dataset.close));
});

document.querySelectorAll(".overlay").forEach(el => {
  el.addEventListener("click", e => {
    if (e.target === el) el.classList.remove("show");
  });
});

// CHECKOUT

$("checkoutBtn").addEventListener("click", () => {
  if (!cart.length) {
    toast("Your cart is empty!");
    return;
  }
  close("cartOverlay");
  open("checkoutOverlay");
});

$("checkoutForm").addEventListener("submit", e => {
  e.preventDefault();
  if (!cart.length) return;

  const order = {
    id:"CB" + Date.now().toString().slice(-6),
    name:$("customerName").value.trim(),
    phone:$("customerPhone").value.trim(),
    pickup:$("pickup").value,
    instructions:$("instructions").value.trim(),
    items:cart.map(i => ({...i})),
    total:total(),
    status:"Received",
    date:new Date().toLocaleString("en-IN")
  };

  orders.unshift(order);
  saveOrders();

  cart = [];
  saveCart();
  updateCart();

  $("successText").textContent =
    `Thank you ${order.name}! Your order ID is ${order.id}. Please pay at the counter when collecting your order.`;

  $("successStatus").textContent = order.status;
  $("checkoutForm").reset();

  close("checkoutOverlay");
  open("successOverlay");
});

$("doneBtn").addEventListener("click", () => {
  close("successOverlay");
  toast("Happy eating!");
});

// ADMIN

$("adminLoginBtn").addEventListener("click", () => {
  if ($("adminPin").value === "1234") {
    $("adminLogin").classList.add("hidden");
    $("adminPanel").classList.remove("hidden");
    $("adminPin").value = "";
    renderAdmin();
  } else {
    toast("Incorrect admin PIN!");
  }
});

function renderAdmin() {
  const revenue = orders.reduce((s,o) => s+o.total,0);

  $("adminStats").innerHTML = `
    <div class="stat-card"><strong>${orders.length}</strong><span>Total Orders</span></div>
    <div class="stat-card"><strong>₹${revenue}</strong><span>Total Order Value</span></div>
  `;

  if (!orders.length) {
    $("adminOrders").innerHTML = "<p>No orders received yet.</p>";
    return;
  }

  $("adminOrders").innerHTML = orders.map(order => {
    const names = order.items.map(item => {
      const p = products.find(p => p.id === item.id);
      return `${p.name} × ${item.quantity}`;
    }).join(", ");

    return `
      <div class="admin-order">
        <h4>${order.id} — ${order.name}</h4>
        <p>${names}</p>
        <p>Phone: ${order.phone}</p>
        <p>Pickup: ${order.pickup}</p>
        <p>Amount: ₹${order.total}</p>
        <p>Date: ${order.date}</p>
        <label>Order status
          <select data-status="${order.id}">
            ${["Received","Preparing","Ready for Pickup","Completed","Cancelled"].map(s =>
              `<option ${order.status===s?"selected":""}>${s}</option>`
            ).join("")}
          </select>
        </label>
      </div>`;
  }).join("");
}

$("adminOrders").addEventListener("change", e => {
  const select = e.target.closest("[data-status]");
  if (!select) return;

  const order = orders.find(o => o.id === select.dataset.status);
  if (order) {
    order.status = select.value;
    saveOrders();
    renderAdmin();
    toast("Order status updated!");
  }
});

$("adminLogout").addEventListener("click", () => {
  $("adminLogin").classList.remove("hidden");
  $("adminPanel").classList.add("hidden");
  close("adminOverlay");
});

// START WEBSITE

renderCategories();
renderProducts();
updateCart();